
package com.example.calceletor;
// Copyright (c) 2020 Saleh Alheeh. All rights reserved
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import java.text.DecimalFormat;
import java.util.ArrayList;

public class MainActivity extends Activity {
    DecimalFormat df = new DecimalFormat("0.###############"); //This object is to delete the point from the numbers

    private Button zero;    //Button declaration For Numbers
    private Button one;
    private Button two;
    private Button three;
    private Button four;
    private Button five;
    private Button six;
    private Button seven;
    private Button eight;
    private Button nine; //End

    private Button addition; //Button declaration For Operation
    private Button division;
    private Button subtract;
    private Button multiply;
    private Button power;    //End

    private Button equal;  //Button declaration For luxuries
    private Button point;
    private Button clearall;
    private ImageButton color_change;
    private ImageButton remove; //End

    private TextView ruslt; //View declaration For Calceletor
    private TextView complete_calculation;
    private TextView number_entered; //End

    private float first_number; //The numbers used in operations
    private float second_number;
    private float third_number;
    private float final_output;
    private boolean enter_num_after_eq=false;
    private boolean enter_op_after_eq=false;
    private int number_of_digits_entered = 0;//number of digits entered from the user
    private int number_of_equal_entered = 0;

    // End

    private int matrix_dictionary;//It is used to rotate to find the text location
    private String store_result; //Store the result of the calculation after the arithmetic operation to stored an array
    private String text_comparison; //It stores array data to compare the text and know the type of operation
    ArrayList<String> The_calculation = new ArrayList<String>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);
        Create_objects();//method call


        point.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(enter_num_after_eq==true) {
                    complete_calculation.setText("");
                    enter_num_after_eq=false;
                }
                if(number_of_digits_entered<=15) {
                    complete_calculation.setText(complete_calculation.getText().toString() + ".");
                    number_entered.setText(number_entered.getText().toString() + ".");
                    number_of_digits_entered++;
                }else{
                    Toast.makeText(getBaseContext(), "Number of Digits more than 15", Toast.LENGTH_SHORT).show();
                }
            }

        });
        zero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(enter_num_after_eq==true) {
                    complete_calculation.setText("");
                    enter_num_after_eq=false;
                }
                if(number_of_digits_entered<=15) {
                    complete_calculation.setText(complete_calculation.getText().toString() + "0");
                    number_entered.setText(number_entered.getText().toString() + "0");
                    number_of_digits_entered++;
                }else{
                    Toast.makeText(getBaseContext(), "Number of Digits more than 15", Toast.LENGTH_SHORT).show();
                }
            }

        });
        one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(enter_num_after_eq==true) {
                    complete_calculation.setText("");
                    enter_num_after_eq=false;
                }
                if(number_of_digits_entered<=15) {
                    complete_calculation.setText(complete_calculation.getText().toString() + "1");
                    number_entered.setText(number_entered.getText().toString() + "1");
                    number_of_digits_entered++;
                }else{
                    Toast.makeText(getBaseContext(), "Number of Digits more than 15", Toast.LENGTH_SHORT).show();
                }
            }

        });
        two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(enter_num_after_eq==true) {
                    complete_calculation.setText("");
                    enter_num_after_eq=false;
                }
                if(number_of_digits_entered<=15) {
                    complete_calculation.setText(complete_calculation.getText().toString() + "2");
                    number_entered.setText(number_entered.getText().toString() + "2");
                    number_of_digits_entered++;
                }else{
                    Toast.makeText(getBaseContext(), "Number of Digits more than 15", Toast.LENGTH_SHORT).show();
                }
            }

        });
        three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(enter_num_after_eq==true) {
                    complete_calculation.setText("");
                    enter_num_after_eq=false;
                }
                if(number_of_digits_entered<=15) {
                    complete_calculation.setText(complete_calculation.getText().toString() + "3");
                    number_entered.setText(number_entered.getText().toString() + "3");
                    number_of_digits_entered++;
                }else{
                    Toast.makeText(getBaseContext(), "Number of Digits more than 15", Toast.LENGTH_SHORT).show();
                }
            }

        });
        four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(enter_num_after_eq==true) {
                    complete_calculation.setText("");
                    enter_num_after_eq=false;
                }
                if(number_of_digits_entered<=15) {
                    complete_calculation.setText(complete_calculation.getText().toString() + "4");
                    number_entered.setText(number_entered.getText().toString() + "4");
                    number_of_digits_entered++;
                }else{
                    Toast.makeText(getBaseContext(), "Number of Digits more than 15", Toast.LENGTH_SHORT).show();
                }
            }

        });
        five.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(enter_num_after_eq==true) {
                    complete_calculation.setText("");
                    enter_num_after_eq=false;
                }
                if(number_of_digits_entered<=15) {
                    complete_calculation.setText(complete_calculation.getText().toString() + "5");
                    number_entered.setText(number_entered.getText().toString() + "5");
                    number_of_digits_entered++;
                }else{
                    Toast.makeText(getBaseContext(), "Number of Digits more than 15", Toast.LENGTH_SHORT).show();
                }
            }

        });
        six.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(enter_num_after_eq==true) {
                    complete_calculation.setText("");
                    enter_num_after_eq=false;
                }
                if(number_of_digits_entered<=15) {
                    complete_calculation.setText(complete_calculation.getText().toString() + "6");
                    number_entered.setText(number_entered.getText().toString() + "6");
                    number_of_digits_entered++;
                }else{
                    Toast.makeText(getBaseContext(), "Number of Digits more than 15", Toast.LENGTH_SHORT).show();
                }
            }

        });
        seven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(enter_num_after_eq==true) {
                    complete_calculation.setText("");
                    enter_num_after_eq=false;
                }
                if(number_of_digits_entered<=15) {
                    complete_calculation.setText(complete_calculation.getText().toString() + "7");
                    number_entered.setText(number_entered.getText().toString() + "7");
                    number_of_digits_entered++;
                }else{
                    Toast.makeText(getBaseContext(), "Number of Digits more than 15", Toast.LENGTH_SHORT).show();
                }
            }

        });
        eight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(enter_num_after_eq==true) {
                    complete_calculation.setText("");
                    enter_num_after_eq=false;
                }
                if(number_of_digits_entered<=15) {
                    complete_calculation.setText(complete_calculation.getText().toString() + "8");
                    number_entered.setText(number_entered.getText().toString() + "8");
                    number_of_digits_entered++;
                }else{
                    Toast.makeText(getBaseContext(), "Number of Digits more than 15", Toast.LENGTH_SHORT).show();
                }
            }

        });
        nine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(enter_num_after_eq==true) {
                    complete_calculation.setText("");
                    enter_num_after_eq=false;
                }
                if(number_of_digits_entered<=15) {
                    complete_calculation.setText(complete_calculation.getText().toString() + "9");
                    number_entered.setText(number_entered.getText().toString() + "9");
                    number_of_digits_entered++;
                }else{
                    Toast.makeText(getBaseContext(), "Number of Digits more than 15", Toast.LENGTH_SHORT).show();
                }
            }

        });

        /**OPERTION WHEN YOU CLICK THE BUTTON **/
        /************************************************************************************* **/

        addition.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    if(number_entered.getText().equals("")){
                        complete_calculation.setText(df.format(final_output));
                        number_of_digits_entered=0;
                        The_calculation.add("+");
                        complete_calculation.setText(complete_calculation.getText().toString() + "+");
                    }else if(number_of_digits_entered>0){
                        Opreationmetod();
                    }
                    if (The_calculation.get(The_calculation.size() - 1).equals("*")) {
                    }else if (number_of_digits_entered>0){
                        The_calculation.add("+");
                        complete_calculation.setText(complete_calculation.getText().toString() + "+");
                        number_of_digits_entered=0;
                    }
                    enter_num_after_eq=false;
                } catch (Exception c) {
                }
            }

        });
        subtract.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if(number_entered.getText().equals("")){
                        complete_calculation.setText(df.format(final_output));
                        number_of_digits_entered=0;
                        The_calculation.add("-");
                        complete_calculation.setText(complete_calculation.getText().toString() + "-");
                    }else if(number_of_digits_entered>0){
                        Opreationmetod();
                    }
                    if (The_calculation.get(The_calculation.size() - 1).equals("*")) {
                    }else if (number_of_digits_entered>0){
                        The_calculation.add("-");
                        complete_calculation.setText(complete_calculation.getText().toString() + "-");
                        number_of_digits_entered=0;
                    }
                    enter_num_after_eq=false;
                } catch (Exception c) {
                }
            }

        });

        multiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if(number_entered.getText().equals("")){
                        complete_calculation.setText(df.format(final_output));
                        number_of_digits_entered=0;
                        The_calculation.add("*");
                        complete_calculation.setText(complete_calculation.getText().toString() + "×");
                    }else if(number_of_digits_entered>0){
                        Opreationmetod();
                    }
                    if (The_calculation.get(The_calculation.size() - 1).equals("*")) {
                    }else if (number_of_digits_entered>0){
                        The_calculation.add("*");
                        complete_calculation.setText(complete_calculation.getText().toString() + "×");
                        number_of_digits_entered=0;
                    }
                    enter_num_after_eq=false;
                } catch (Exception c) {
                }

            }

        });
        division.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if(number_entered.getText().equals("")){
                        complete_calculation.setText(df.format(final_output));
                        number_of_digits_entered=0;
                        The_calculation.add("/");
                        complete_calculation.setText(complete_calculation.getText().toString() + "÷");
                    }else if(number_of_digits_entered>0){
                        Opreationmetod();
                    }
                    if (The_calculation.get(The_calculation.size() - 1).equals("/")) {
                    }else if (number_of_digits_entered>0){
                        The_calculation.add("/");
                        complete_calculation.setText(complete_calculation.getText().toString() + "÷");
                        number_of_digits_entered=0;
                    }
                    enter_num_after_eq=false;
                } catch (Exception c) {
                }
            }

        });
        /**OPERTION WHEN YOU CLICK THE BUTTON **/
        /************************************************************************************* **/

        equal.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (number_of_digits_entered>0) {
                    Equalmethod();
                    number_of_digits_entered=0;
                    enter_num_after_eq=true;
                }
            }
        });

            remove.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });
        clearall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                complete_calculation.setText("");
                ruslt.setText("");
                number_entered.setText("");
                The_calculation.clear();
                number_of_digits_entered=0;
                number_of_equal_entered=0;
                enter_num_after_eq=false;
            }
        });



        color_change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                color_change.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                one.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                zero.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                one.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                two.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                three.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                four.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                five.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                six.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                seven.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                eight.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                nine.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                addition.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                division.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                subtract.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                multiply.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                equal.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                Toast.makeText(getBaseContext(), "Button background color green", Toast.LENGTH_SHORT).show();
            }
        });
    }
     private void Equalmethod(){
        The_calculation.add(number_entered.getText().toString());
        for (matrix_dictionary = 0; matrix_dictionary < The_calculation.size(); matrix_dictionary++) {
            text_comparison = The_calculation.get(matrix_dictionary);
            if (text_comparison.equals("^")) {

            } else if (text_comparison.equals("*") || text_comparison.equals("/")) {
                if (text_comparison.equals("*")) {
                    Multiplymethod();
                } else {
                    Divisionmethod();
                }
            } else if (text_comparison.equals("+") || text_comparison.equals("-")) {
                if (text_comparison.equals("+")) {
                    Additionmethod();
                } else {
                    Subtractmethod();
                }
            }
        }
        final_output=Float.parseFloat(The_calculation.get(0));
        ruslt.setText(df.format(final_output));
        number_entered.setText("");
    }
    private void Opreationmetod(){
        The_calculation.add(number_entered.getText().toString());
        number_entered.setText("");
    }
    private void Multiplymethod() {
        first_number=Float.parseFloat(The_calculation.get(matrix_dictionary-1));
        second_number=Float.parseFloat(The_calculation.get(matrix_dictionary+1));
        third_number=first_number*second_number;
        The_calculation.remove(matrix_dictionary-1);
        The_calculation.remove(matrix_dictionary-1);
        The_calculation.remove(matrix_dictionary-1);
        store_result = Float.toString(third_number);
        The_calculation.add(matrix_dictionary-1,store_result);
        matrix_dictionary=0;
    }
    private void Divisionmethod() {
        first_number=Float.parseFloat(The_calculation.get(matrix_dictionary-1));
        second_number=Float.parseFloat(The_calculation.get(matrix_dictionary+1));
        third_number=first_number/second_number;
        The_calculation.remove(matrix_dictionary-1);
        The_calculation.remove(matrix_dictionary-1);
        The_calculation.remove(matrix_dictionary-1);
        store_result = Float.toString(third_number);
        The_calculation.add(matrix_dictionary-1,store_result);
        matrix_dictionary=0;
    }
   private void Additionmethod() {
       first_number=Float.parseFloat(The_calculation.get(matrix_dictionary-1));
       second_number=Float.parseFloat(The_calculation.get(matrix_dictionary+1));
       third_number=first_number+second_number;
       The_calculation.remove(matrix_dictionary-1);
       The_calculation.remove(matrix_dictionary-1);
       The_calculation.remove(matrix_dictionary-1);
       store_result = Float.toString(third_number);
       The_calculation.add(matrix_dictionary-1,store_result);
       matrix_dictionary=0;
    }
    private void Subtractmethod() {
        first_number=Float.parseFloat(The_calculation.get(matrix_dictionary-1));
        second_number=Float.parseFloat(The_calculation.get(matrix_dictionary+1));
        third_number=first_number-second_number;
        The_calculation.remove(matrix_dictionary-1);
        The_calculation.remove(matrix_dictionary-1);
        The_calculation.remove(matrix_dictionary-1);
        store_result = Float.toString(third_number);
        The_calculation.add(matrix_dictionary-1,store_result);
        matrix_dictionary=0;
    }
    private void Create_objects() { //This function is to link the interface and the code
        zero = (Button) findViewById(R.id.but0);
        one = (Button) findViewById(R.id.but1);
        two = (Button) findViewById(R.id.but2);
        three = (Button) findViewById(R.id.but3);
        four = (Button) findViewById(R.id.but4);
        five = (Button) findViewById(R.id.but5);
        six = (Button) findViewById(R.id.but6);
        seven = (Button) findViewById(R.id.but7);
        eight = (Button) findViewById(R.id.but8);
        nine = (Button) findViewById(R.id.but9);
        addition = (Button) findViewById(R.id.add);
        division = (Button) findViewById(R.id.div);
        subtract = (Button) findViewById(R.id.sub);
        multiply = (Button) findViewById(R.id.mult);
        equal = (Button) findViewById(R.id.eq);
        point = (Button) findViewById(R.id.point);
        ruslt = (TextView) findViewById(R.id.ruslttxt);
        number_entered = (TextView) findViewById(R.id.Enter);
        complete_calculation = (TextView) findViewById(R.id.inftxt);
        clearall = (Button) findViewById(R.id.ac);
        color_change= (ImageButton)findViewById(R.id.changes);
        remove= (ImageButton)findViewById(R.id.remove);
        power = (Button) findViewById(R.id.power);
    }
}




